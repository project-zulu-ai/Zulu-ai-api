import { aiService } from "./aiService";

export interface GeneratedProject {
  name: string;
  description: string;
  techStack: string[];
  files: { [key: string]: string };
  structure: any;
  features: string[];
  complexity: string;
  estimatedTime: string;
}

class CodeGenerator {
  async generateFullStackApp(idea: string): Promise<GeneratedProject> {
    try {
      console.log("Starting full-stack app generation for:", idea);

      // Step 1: Analyze the project idea
      const analysis = await aiService.analyzeProjectIdea(idea);
      console.log("Project analysis completed:", analysis.name);

      // Step 2: Generate base project structure and core files
      const projectData = await aiService.generateProjectStructure(idea, analysis.techStack);
      console.log("Base project structure generated");

      // Step 3: Generate additional advanced files
      const advancedFiles = await aiService.generateAdvancedFiles(
        idea, 
        analysis.techStack, 
        projectData.files
      );
      console.log("Advanced files generated");

      // Step 4: Combine all files
      const allFiles = {
        ...projectData.files,
        ...advancedFiles,
        // Add essential configuration files
        ".env.example": this.generateEnvExample(analysis.techStack),
        ".gitignore": this.generateGitignore(analysis.techStack),
        "README.md": this.generateReadme(analysis),
      };

      // Step 5: Return complete project
      const generatedProject: GeneratedProject = {
        name: analysis.name,
        description: analysis.description,
        techStack: analysis.techStack,
        files: allFiles,
        structure: projectData.structure,
        features: analysis.features,
        complexity: analysis.complexity,
        estimatedTime: analysis.estimatedTime,
      };

      console.log("Full-stack app generation completed:", generatedProject.name);
      return generatedProject;

    } catch (error) {
      console.error("Error in generateFullStackApp:", error);
      throw new Error(`Failed to generate application: ${error.message}`);
    }
  }

  private generateEnvExample(techStack: string[]): string {
    let envContent = `# Environment Variables
NODE_ENV=development
PORT=5000

# Database
DATABASE_URL=postgresql://username:password@localhost:5432/database_name

# Authentication
SESSION_SECRET=your-super-secret-session-key
JWT_SECRET=your-jwt-secret-key

`;

    if (techStack.includes("OpenAI") || techStack.includes("AI")) {
      envContent += `# AI Services
OPENAI_API_KEY=your-openai-api-key
`;
    }

    if (techStack.includes("Stripe") || techStack.includes("Payment")) {
      envContent += `# Payment
STRIPE_SECRET_KEY=your-stripe-secret-key
STRIPE_PUBLISHABLE_KEY=your-stripe-publishable-key
`;
    }

    if (techStack.includes("Redis")) {
      envContent += `# Redis
REDIS_URL=redis://localhost:6379
`;
    }

    if (techStack.includes("Email") || techStack.includes("SendGrid")) {
      envContent += `# Email
SENDGRID_API_KEY=your-sendgrid-api-key
FROM_EMAIL=noreply@yourapp.com
`;
    }

    return envContent;
  }

  private generateGitignore(techStack: string[]): string {
    let gitignoreContent = `# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Production builds
/build
/dist
/.next

# Environment variables
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# Logs
logs
*.log

# Runtime data
pids
*.pid
*.seed
*.pid.lock

# Coverage directory used by tools like istanbul
coverage/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Database
*.sqlite
*.db

`;

    if (techStack.includes("Python")) {
      gitignoreContent += `# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
.venv/
pip-log.txt
pip-delete-this-directory.txt

`;
    }

    if (techStack.includes("Docker")) {
      gitignoreContent += `# Docker
.dockerignore

`;
    }

    return gitignoreContent;
  }

  private generateReadme(analysis: any): string {
    return `# ${analysis.name}

${analysis.description}

## Features

${analysis.features.map((feature: string) => `- ${feature}`).join('\n')}

## Tech Stack

${analysis.techStack.map((tech: string) => `- ${tech}`).join('\n')}

## Project Complexity

**${analysis.complexity}** - Estimated time: ${analysis.estimatedTime}

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn
- PostgreSQL database

### Installation

1. Clone the repository
\`\`\`bash
git clone <your-repo-url>
cd ${analysis.name.toLowerCase().replace(/\s+/g, '-')}
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables
\`\`\`bash
cp .env.example .env
# Edit .env with your actual values
\`\`\`

4. Set up the database
\`\`\`bash
npm run db:push
\`\`\`

5. Start the development server
\`\`\`bash
npm run dev
\`\`\`

The application will be available at \`http://localhost:5000\`

## Architecture

### Frontend
${analysis.architecture?.frontend || 'Modern React application with responsive design'}

### Backend  
${analysis.architecture?.backend || 'RESTful API with Express.js'}

### Database
${analysis.architecture?.database || 'PostgreSQL with proper data modeling'}

## Deployment

The application is ready for deployment to platforms like:
- Vercel
- Netlify
- Railway
- Heroku
- DigitalOcean

## Contributing

1. Fork the project
2. Create your feature branch (\`git checkout -b feature/AmazingFeature\`)
3. Commit your changes (\`git commit -m 'Add some AmazingFeature'\`)
4. Push to the branch (\`git push origin feature/AmazingFeature\`)
5. Open a Pull Request

## License

This project is licensed under the MIT License.

---

*Generated by Zulu AI - African AI-Powered Development Platform*
`;
  }
}

export const codeGenerator = new CodeGenerator();
