import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

class AIService {
  constructor() {
    // Gemini AI service initialization
  }

  async analyzeProjectIdea(idea: string): Promise<{
    name: string;
    description: string;
    techStack: string[];
    complexity: 'simple' | 'medium' | 'complex';
    estimatedTime: string;
    features: string[];
    architecture: any;
  }> {
    try {
      const systemPrompt = `You are an expert software architect. Analyze the given app idea and provide a structured analysis. 
Respond with JSON in this exact format: 
{
  "name": "Project Name",
  "description": "Brief description",
  "techStack": ["React", "Express.js", "PostgreSQL"],
  "complexity": "simple|medium|complex",
  "estimatedTime": "time estimate",
  "features": ["feature1", "feature2"],
  "architecture": {
    "frontend": "description",
    "backend": "description",
    "database": "description"
  }
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              name: { type: "string" },
              description: { type: "string" },
              techStack: { type: "array", items: { type: "string" } },
              complexity: { type: "string", enum: ["simple", "medium", "complex"] },
              estimatedTime: { type: "string" },
              features: { type: "array", items: { type: "string" } },
              architecture: {
                type: "object",
                properties: {
                  frontend: { type: "string" },
                  backend: { type: "string" },
                  database: { type: "string" }
                }
              }
            },
            required: ["name", "description", "techStack", "complexity", "estimatedTime", "features", "architecture"]
          }
        },
        contents: `Analyze this app idea: ${idea}`
      });

      const result = JSON.parse(response.text || "{}");
      return result;
    } catch (error) {
      console.error("Error analyzing project idea:", error);
      throw new Error("Failed to analyze project idea");
    }
  }

  async generateProjectStructure(idea: string, techStack: string[]): Promise<{
    structure: any;
    files: { [key: string]: string };
  }> {
    try {
      const systemPrompt = `You are an expert full-stack developer. Generate a complete project structure and key files for the given idea using the specified tech stack.

Respond with JSON in this format:
{
  "structure": {
    "directories": ["dir1", "dir2"],
    "files": ["file1.js", "file2.tsx"]
  },
  "files": {
    "package.json": "file content",
    "src/App.tsx": "file content",
    "server/index.js": "file content"
  }
}

Generate actual, working code for each file. Include:
- Complete package.json with all dependencies
- Main application files
- Database schemas if needed
- Basic styling
- README with setup instructions

Make sure the code is production-ready and follows best practices.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              structure: {
                type: "object",
                properties: {
                  directories: { type: "array", items: { type: "string" } },
                  files: { type: "array", items: { type: "string" } }
                }
              },
              files: {
                type: "object",
                additionalProperties: { type: "string" }
              }
            },
            required: ["structure", "files"]
          }
        },
        contents: `Generate a complete project for: ${idea}
            
Tech Stack: ${techStack.join(", ")}
            
Requirements:
- Production-ready code
- Modern best practices
- Complete file structure
- Working functionality
- Proper error handling
- Authentication if needed
- Database integration if needed
- Responsive design
- Clean, documented code`
      });

      const result = JSON.parse(response.text || "{}");
      return result;
    } catch (error) {
      console.error("Error generating project structure:", error);
      throw new Error("Failed to generate project structure");
    }
  }

  async generateAdvancedFiles(idea: string, techStack: string[], baseFiles: any): Promise<{
    [key: string]: string;
  }> {
    try {
      const systemPrompt = `You are an expert developer. Given a project idea, tech stack, and base file structure, generate additional advanced files and components needed for a complete application.

Focus on:
- Advanced components and utilities
- Configuration files
- Testing files
- Deployment configurations
- API documentation
- Advanced features

Respond with JSON where keys are file paths and values are file contents.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            additionalProperties: { type: "string" }
          }
        },
        contents: `Project: ${idea}
Tech Stack: ${techStack.join(", ")}
Base Files: ${JSON.stringify(Object.keys(baseFiles))}

Generate additional advanced files needed to complete this project.`
      });

      const result = JSON.parse(response.text || "{}");
      return result;
    } catch (error) {
      console.error("Error generating advanced files:", error);
      throw new Error("Failed to generate advanced files");
    }
  }

  async improveSuggestions(idea: string, currentFeatures: string[]): Promise<{
    suggestions: string[];
    improvements: string[];
    nextSteps: string[];
  }> {
    try {
      const systemPrompt = `You are a product manager and technical advisor. Analyze the given app idea and current features, then suggest improvements and next steps. Respond with JSON in this format:
{
  "suggestions": ["suggestion1", "suggestion2"],
  "improvements": ["improvement1", "improvement2"],
  "nextSteps": ["step1", "step2"]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              suggestions: { type: "array", items: { type: "string" } },
              improvements: { type: "array", items: { type: "string" } },
              nextSteps: { type: "array", items: { type: "string" } }
            },
            required: ["suggestions", "improvements", "nextSteps"]
          }
        },
        contents: `App Idea: ${idea}
Current Features: ${currentFeatures.join(", ")}

Provide suggestions for enhancements, improvements, and next development steps.`
      });

      const result = JSON.parse(response.text || "{}");
      return result;
    } catch (error) {
      console.error("Error generating improvement suggestions:", error);
      throw new Error("Failed to generate improvement suggestions");
    }
  }
}

export const aiService = new AIService();
