import {
  users,
  projects,
  apiUsage,
  userSettings,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type ApiUsage,
  type InsertApiUsage,
  type UserSettings,
  type InsertUserSettings,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Project operations
  getUserProjects(userId: string): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  getUserProject(userId: string, projectId: string): Promise<Project | undefined>;
  createProject(userId: string, project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: Partial<Project>): Promise<Project>;
  deleteProject(id: string): Promise<void>;
  incrementDownloadCount(id: string): Promise<void>;
  
  // API usage operations
  getApiUsage(userId: string, month: string): Promise<ApiUsage | undefined>;
  updateApiUsage(userId: string, usage: InsertApiUsage): Promise<ApiUsage>;
  
  // User settings operations
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  upsertUserSettings(userId: string, settings: InsertUserSettings): Promise<UserSettings>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Project operations
  async getUserProjects(userId: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(eq(projects.userId, userId))
      .orderBy(desc(projects.createdAt));
  }

  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getUserProject(userId: string, projectId: string): Promise<Project | undefined> {
    const [project] = await db
      .select()
      .from(projects)
      .where(and(eq(projects.id, projectId), eq(projects.userId, userId)));
    return project;
  }

  async createProject(userId: string, project: InsertProject): Promise<Project> {
    const [newProject] = await db
      .insert(projects)
      .values({
        ...project,
        userId,
      })
      .returning();
    return newProject;
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project> {
    const [project] = await db
      .update(projects)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  async incrementDownloadCount(id: string): Promise<void> {
    await db
      .update(projects)
      .set({
        downloadCount: sql`${projects.downloadCount} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, id));
  }

  // API usage operations
  async getApiUsage(userId: string, month: string): Promise<ApiUsage | undefined> {
    const [usage] = await db
      .select()
      .from(apiUsage)
      .where(and(eq(apiUsage.userId, userId), eq(apiUsage.month, month)));
    return usage;
  }

  async updateApiUsage(userId: string, usage: InsertApiUsage): Promise<ApiUsage> {
    const [existingUsage] = await db
      .select()
      .from(apiUsage)
      .where(and(eq(apiUsage.userId, userId), eq(apiUsage.month, usage.month)));

    if (existingUsage) {
      const [updatedUsage] = await db
        .update(apiUsage)
        .set({
          projectsGenerated: usage.projectsGenerated || existingUsage.projectsGenerated,
          apiCallsUsed: usage.apiCallsUsed || existingUsage.apiCallsUsed,
          updatedAt: new Date(),
        })
        .where(and(eq(apiUsage.userId, userId), eq(apiUsage.month, usage.month)))
        .returning();
      return updatedUsage;
    } else {
      const [newUsage] = await db
        .insert(apiUsage)
        .values({
          ...usage,
          userId,
        })
        .returning();
      return newUsage;
    }
  }

  // User settings operations
  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    const [settings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, userId));
    return settings;
  }

  async upsertUserSettings(userId: string, settings: InsertUserSettings): Promise<UserSettings> {
    const [existingSettings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, userId));

    if (existingSettings) {
      const [updatedSettings] = await db
        .update(userSettings)
        .set({
          ...settings,
          updatedAt: new Date(),
        })
        .where(eq(userSettings.userId, userId))
        .returning();
      return updatedSettings;
    } else {
      const [newSettings] = await db
        .insert(userSettings)
        .values({
          ...settings,
          userId,
        })
        .returning();
      return newSettings;
    }
  }
}

export const storage = new DatabaseStorage();
