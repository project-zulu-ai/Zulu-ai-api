import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { aiService } from "./services/aiService";
import { codeGenerator } from "./services/codeGenerator";
import { insertProjectSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Project routes
  app.get('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projects = await storage.getUserProjects(userId);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const project = await storage.getUserProject(userId, id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post('/api/projects/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Validate request body
      const validationSchema = insertProjectSchema.extend({
        idea: z.string().min(10, "Please provide a more detailed description"),
      });
      
      const validatedData = validationSchema.parse(req.body);
      
      // Check API usage limits (basic implementation)
      const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
      const usage = await storage.getApiUsage(userId, currentMonth);
      
      // For now, limit to 10 projects per month for free users
      if (usage && usage.projectsGenerated >= 10) {
        return res.status(429).json({ 
          message: "Monthly project generation limit reached. Please upgrade your plan." 
        });
      }

      // Create project record
      const project = await storage.createProject(userId, {
        ...validatedData,
        status: "generating",
      });

      // Start background generation process
      generateProjectInBackground(project.id, validatedData.idea);

      res.json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.delete('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      // Verify ownership
      const project = await storage.getUserProject(userId, id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      await storage.deleteProject(id);
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      console.error("Error deleting project:", error);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  app.post('/api/projects/:id/download', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const project = await storage.getUserProject(userId, id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      if (project.status !== "completed") {
        return res.status(400).json({ message: "Project is not ready for download" });
      }
      
      // Increment download count
      await storage.incrementDownloadCount(id);
      
      // Return download data (files)
      res.json({
        name: project.name,
        files: project.files,
        techStack: project.techStack,
      });
    } catch (error) {
      console.error("Error downloading project:", error);
      res.status(500).json({ message: "Failed to download project" });
    }
  });

  // User settings routes
  app.get('/api/user/settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const settings = await storage.getUserSettings(userId);
      res.json(settings || {
        theme: 'light',
        defaultTechStack: ['React', 'Express.js', 'PostgreSQL'],
        notifications: { email: true, push: false }
      });
    } catch (error) {
      console.error("Error fetching user settings:", error);
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });

  app.put('/api/user/settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const settings = await storage.upsertUserSettings(userId, req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating user settings:", error);
      res.status(500).json({ message: "Failed to update user settings" });
    }
  });

  // API usage stats
  app.get('/api/user/usage', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const currentMonth = new Date().toISOString().slice(0, 7);
      const usage = await storage.getApiUsage(userId, currentMonth);
      
      res.json(usage || {
        projectsGenerated: 0,
        apiCallsUsed: 0,
        month: currentMonth
      });
    } catch (error) {
      console.error("Error fetching API usage:", error);
      res.status(500).json({ message: "Failed to fetch API usage" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Background task for project generation
async function generateProjectInBackground(projectId: string, idea: string) {
  try {
    console.log(`Starting generation for project ${projectId}`);
    
    // Update status to generating
    await storage.updateProject(projectId, { status: "generating" });
    
    // Generate the application using AI
    const generatedProject = await codeGenerator.generateFullStackApp(idea);
    
    // Update project with generated files
    await storage.updateProject(projectId, {
      status: "completed",
      files: generatedProject.files,
      techStack: generatedProject.techStack,
    });
    
    console.log(`Generation completed for project ${projectId}`);
  } catch (error) {
    console.error(`Generation failed for project ${projectId}:`, error);
    await storage.updateProject(projectId, { 
      status: "failed" 
    });
  }
}
