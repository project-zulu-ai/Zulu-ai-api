import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Navbar } from "@/components/navbar";
import { AppGenerator } from "@/components/app-generator";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { 
  Plus, 
  BarChart3, 
  Clock, 
  Zap,
  TrendingUp,
  Users,
  Globe,
  Star
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ["/api/projects"],
    retry: false,
  });

  const { data: usage } = useQuery({
    queryKey: ["/api/user/usage"],
    retry: false,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const recentProjects = projects?.slice(0, 3) || [];
  const completedProjects = projects?.filter((p: any) => p.status === "completed").length || 0;
  const monthlyUsage = usage?.projectsGenerated || 0;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Welcome back, {user?.firstName || 'Developer'}! 👋
            </h1>
            <p className="text-xl text-muted-foreground">
              Ready to turn your next big idea into reality with AI?
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Projects Generated</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{projects?.length || 0}</div>
                <p className="text-xs text-muted-foreground">
                  {completedProjects} completed
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">This Month</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{monthlyUsage}</div>
                <p className="text-xs text-muted-foreground">
                  {10 - monthlyUsage} remaining
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">96%</div>
                <p className="text-xs text-muted-foreground">
                  Generation success
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Plan</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Free</div>
                <p className="text-xs text-muted-foreground">
                  <Button variant="link" className="p-0 h-auto text-xs">Upgrade</Button>
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Grid */}
          <div className="grid lg:grid-cols-2 gap-12">
            {/* App Generator */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-foreground">Generate New App</h2>
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <AppGenerator />
            </div>

            {/* Recent Projects */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-foreground">Recent Projects</h2>
                <Link href="/dashboard" data-testid="link-view-all">
                  <Button variant="outline" size="sm">View All</Button>
                </Link>
              </div>

              {projectsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-muted rounded w-1/2"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : recentProjects.length > 0 ? (
                <div className="space-y-4">
                  {recentProjects.map((project: any) => (
                    <Card key={project.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold text-foreground mb-1">{project.name}</h3>
                            <p className="text-sm text-muted-foreground mb-2">{project.description}</p>
                            <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                              <span className={`px-2 py-1 rounded-full ${
                                project.status === "completed" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100" :
                                project.status === "generating" ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100" :
                                project.status === "failed" ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100" :
                                "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100"
                              }`}>
                                {project.status}
                              </span>
                              <span>{new Date(project.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" data-testid={`button-view-project-${project.id}`}>
                            View
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Plus className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">No projects yet</h3>
                    <p className="text-muted-foreground text-center mb-4">
                      Create your first AI-generated application to get started
                    </p>
                    <Button data-testid="button-create-first-project">
                      <Plus className="mr-2 h-4 w-4" />
                      Create First Project
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Community Stats */}
          <div className="mt-16">
            <Card className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-foreground mb-2">Join the African AI Revolution</h2>
                  <p className="text-muted-foreground">
                    Be part of the growing community of developers building the future with African innovation
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                  <div>
                    <div className="flex items-center justify-center mb-4">
                      <Users className="h-8 w-8 text-primary" />
                    </div>
                    <div className="text-3xl font-bold text-foreground mb-2">10,000+</div>
                    <div className="text-muted-foreground">Active Developers</div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-center mb-4">
                      <Globe className="h-8 w-8 text-secondary" />
                    </div>
                    <div className="text-3xl font-bold text-foreground mb-2">50+</div>
                    <div className="text-muted-foreground">Countries Served</div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-center mb-4">
                      <Zap className="h-8 w-8 text-accent" />
                    </div>
                    <div className="text-3xl font-bold text-foreground mb-2">100,000+</div>
                    <div className="text-muted-foreground">Apps Generated</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
