import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Navbar } from "@/components/navbar";
import { 
  Brain, 
  Layers, 
  Shield, 
  GitBranch, 
  Smartphone, 
  Globe,
  Sparkles,
  Rocket,
  Play,
  Check,
  Folder,
  File,
  Download,
  Eye,
  Edit,
  MoreVertical,
  CheckCircle,
  Code,
  Twitter,
  Github,
  Linkedin,
  MessageCircle
} from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-pattern min-h-screen flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="inline-flex items-center space-x-2 bg-accent/20 text-accent-foreground px-3 py-1 rounded-full text-sm">
                  <Sparkles className="h-4 w-4" />
                  <span>Powered by African Innovation</span>
                </div>
                <h1 className="text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                  Build Apps with 
                  <span className="text-primary"> AI Power</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-lg">
                  Transform your ideas into production-ready applications using our African-built AI platform. Compete with the best, built for the world.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg"
                  className="px-8 py-4 hover:scale-105 transition-all"
                  onClick={() => window.location.href = "/api/login"}
                  data-testid="button-start-building"
                >
                  <Rocket className="mr-2 h-5 w-5" />
                  Start Building Free
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="px-8 py-4"
                  data-testid="button-watch-demo"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Watch Demo
                </Button>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-foreground">10K+</div>
                  <div className="text-sm text-muted-foreground">Apps Generated</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-foreground">50+</div>
                  <div className="text-sm text-muted-foreground">Countries</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-foreground">99.9%</div>
                  <div className="text-sm text-muted-foreground">Uptime</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <Card className="glass-card p-6 rounded-2xl animate-float">
                <CardContent className="space-y-4 p-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-foreground">AI App Generator</h3>
                    <div className="flex space-x-1">
                      <div className="w-3 h-3 bg-destructive rounded-full"></div>
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <div className="w-3 h-3 bg-accent rounded-full"></div>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-foreground">Describe your app idea</label>
                    <Textarea 
                      placeholder="Create a task management app with real-time collaboration, user authentication, and project boards..."
                      className="h-24 resize-none"
                      data-testid="textarea-app-idea"
                    />
                    
                    <Button className="w-full" data-testid="button-generate-app">
                      <Sparkles className="mr-2 h-4 w-4" />
                      Generate App
                    </Button>
                  </div>

                  <div className="mt-6 space-y-2">
                    <div className="text-xs text-muted-foreground">Recent generations:</div>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 p-2 bg-muted rounded-lg">
                        <CheckCircle className="h-4 w-4 text-accent" />
                        <span className="text-sm text-foreground">E-commerce Platform</span>
                        <span className="text-xs text-muted-foreground ml-auto">2m ago</span>
                      </div>
                      <div className="flex items-center space-x-2 p-2 bg-muted rounded-lg">
                        <CheckCircle className="h-4 w-4 text-accent" />
                        <span className="text-sm text-foreground">Social Media Dashboard</span>
                        <span className="text-xs text-muted-foreground ml-auto">5m ago</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-foreground">Powerful Features for Modern Development</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Built with African innovation and global standards, our platform offers everything you need to create professional applications.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-6 hover:shadow-lg transition-all">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                  <Brain className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">AI-Powered Generation</h3>
                <p className="text-muted-foreground">Transform natural language descriptions into full-stack applications with our advanced AI models.</p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center mb-4">
                  <Layers className="text-secondary h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Full-Stack Architecture</h3>
                <p className="text-muted-foreground">Generate complete applications with FastAPI backend, React frontend, and database integration.</p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="text-accent h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Production Ready</h3>
                <p className="text-muted-foreground">All generated code includes authentication, security, testing, and deployment configurations.</p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                  <GitBranch className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Version Control</h3>
                <p className="text-muted-foreground">Integrated Git workflows and CI/CD pipelines for seamless development and deployment.</p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center mb-4">
                  <Smartphone className="text-secondary h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Responsive Design</h3>
                <p className="text-muted-foreground">All applications are built with mobile-first approach and responsive design principles.</p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4">
                  <Globe className="text-accent h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">African Innovation</h3>
                <p className="text-muted-foreground">Built by African developers, for global developers, representing the continent in AI innovation.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* App Generation Demo */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-foreground">See Zulu AI in Action</h2>
            <p className="text-xl text-muted-foreground">Watch how quickly you can go from idea to production-ready application</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div className="space-y-6">
              <Card className="p-6">
                <CardContent className="p-0">
                  <h3 className="text-lg font-semibold text-card-foreground mb-4 flex items-center">
                    <Sparkles className="text-primary mr-2 h-5 w-5" />
                    Your Idea
                  </h3>
                  <div className="bg-muted p-4 rounded-lg">
                    <p className="text-muted-foreground font-mono text-sm">
                      "Create a project management tool with kanban boards, team collaboration, time tracking, and real-time notifications. Include user authentication and role-based permissions."
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="p-6">
                <CardContent className="p-0">
                  <h3 className="text-lg font-semibold text-card-foreground mb-4 flex items-center">
                    <Brain className="text-secondary mr-2 h-5 w-5" />
                    AI Processing
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 bg-accent rounded-full animate-pulse"></div>
                      <span className="text-sm text-foreground">Analyzing requirements...</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 bg-accent rounded-full animate-pulse"></div>
                      <span className="text-sm text-foreground">Generating architecture...</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 bg-accent rounded-full animate-pulse"></div>
                      <span className="text-sm text-foreground">Creating components...</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="p-6">
                <CardContent className="p-0">
                  <h3 className="text-lg font-semibold text-card-foreground mb-4 flex items-center">
                    <Download className="text-accent mr-2 h-5 w-5" />
                    Download & Deploy
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4">Your complete application ready for deployment</p>
                  <Button className="w-full" data-testid="button-download-project">
                    <Download className="mr-2 h-4 w-4" />
                    Download Project
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="p-6">
                <CardContent className="p-0">
                  <h3 className="text-lg font-semibold text-card-foreground mb-4">Generated Project Structure</h3>
                  <div className="code-preview p-4 rounded-lg font-mono text-sm">
                    <div className="space-y-1 text-foreground">
                      <div className="flex items-center space-x-2">
                        <Folder className="h-4 w-4 text-secondary" />
                        <span>project-manager/</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Folder className="h-4 w-4 text-secondary" />
                        <span>backend/</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-8">
                        <File className="h-4 w-4 text-muted-foreground" />
                        <span>main.py</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-8">
                        <Folder className="h-4 w-4 text-secondary" />
                        <span>api/</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-8">
                        <Folder className="h-4 w-4 text-secondary" />
                        <span>models/</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Folder className="h-4 w-4 text-secondary" />
                        <span>frontend/</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-8">
                        <File className="h-4 w-4 text-muted-foreground" />
                        <span>App.jsx</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-8">
                        <Folder className="h-4 w-4 text-secondary" />
                        <span>components/</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <File className="h-4 w-4 text-muted-foreground" />
                        <span>docker-compose.yml</span>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <File className="h-4 w-4 text-muted-foreground" />
                        <span>README.md</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-2 gap-4">
                <Card className="p-4 text-center">
                  <CardContent className="p-0">
                    <div className="text-2xl font-bold text-foreground">2.5s</div>
                    <div className="text-sm text-muted-foreground">Generation Time</div>
                  </CardContent>
                </Card>
                <Card className="p-4 text-center">
                  <CardContent className="p-0">
                    <div className="text-2xl font-bold text-foreground">50+</div>
                    <div className="text-sm text-muted-foreground">Files Created</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-foreground">Simple, Transparent Pricing</h2>
            <p className="text-xl text-muted-foreground">Choose the plan that works best for your development needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Free Plan */}
            <Card className="p-8 text-center">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Starter</h3>
                <div className="text-4xl font-bold text-foreground mb-1">Free</div>
                <p className="text-muted-foreground text-sm mb-6">Perfect for getting started</p>
                
                <ul className="space-y-3 mb-8 text-left">
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">3 projects per month</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">Basic templates</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">Community support</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">Standard deployment</span>
                  </li>
                </ul>
                
                <Button variant="outline" className="w-full" data-testid="button-get-started-free">
                  Get Started Free
                </Button>
              </CardContent>
            </Card>

            {/* Pro Plan */}
            <Card className="p-8 text-center bg-primary text-primary-foreground relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-accent text-accent-foreground px-4 py-1 rounded-full text-sm font-medium">
                Most Popular
              </div>
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold mb-2">Professional</h3>
                <div className="text-4xl font-bold mb-1">$29</div>
                <p className="text-primary-foreground/80 text-sm mb-6">per month</p>
                
                <ul className="space-y-3 mb-8 text-left">
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span>Unlimited projects</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span>Advanced templates</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span>Priority support</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span>Custom deployments</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span>API access</span>
                  </li>
                </ul>
                
                <Button variant="secondary" className="w-full" data-testid="button-start-pro-trial">
                  Start Pro Trial
                </Button>
              </CardContent>
            </Card>

            {/* Enterprise Plan */}
            <Card className="p-8 text-center">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Enterprise</h3>
                <div className="text-4xl font-bold text-foreground mb-1">Custom</div>
                <p className="text-muted-foreground text-sm mb-6">For large organizations</p>
                
                <ul className="space-y-3 mb-8 text-left">
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">Everything in Pro</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">White-label solution</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">Dedicated support</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">Custom integrations</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-accent" />
                    <span className="text-foreground">SLA guarantee</span>
                  </li>
                </ul>
                
                <Button variant="outline" className="w-full" data-testid="button-contact-sales">
                  Contact Sales
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 bg-muted/30 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <Code className="text-primary-foreground font-bold h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-foreground">Zulu AI</h3>
                  <p className="text-xs text-muted-foreground">African AI Development</p>
                </div>
              </div>
              <p className="text-muted-foreground">
                Empowering developers across Africa and the world with AI-powered application generation.
              </p>
              <div className="flex space-x-4">
                <Twitter className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors cursor-pointer" />
                <Github className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors cursor-pointer" />
                <Linkedin className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors cursor-pointer" />
                <MessageCircle className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors cursor-pointer" />
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-4">Product</h4>
              <ul className="space-y-2">
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Features</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Templates</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Integrations</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">API</span></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-4">Resources</h4>
              <ul className="space-y-2">
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Documentation</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Tutorials</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Blog</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Community</span></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-4">Company</h4>
              <ul className="space-y-2">
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">About</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Careers</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Contact</span></li>
                <li><span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Privacy</span></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-muted-foreground text-sm">
              © 2024 Zulu AI. Built with pride in Africa for the world.
            </p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-muted-foreground text-sm">Made in</span>
              <span className="text-primary font-semibold">🌍 Africa</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
