import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Eye, 
  Edit, 
  MoreVertical, 
  Download, 
  Trash2,
  Clock,
  CheckCircle,
  XCircle,
  Loader2,
  Code,
  Calendar,
  TrendingUp
} from "lucide-react";
import { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
  viewMode: "grid" | "list";
  onDelete: (id: string) => void;
  onDownload: (id: string) => void;
  isDeleting: boolean;
  isDownloading: boolean;
}

export function ProjectCard({ 
  project, 
  viewMode, 
  onDelete, 
  onDownload,
  isDeleting,
  isDownloading 
}: ProjectCardProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "completed":
        return {
          icon: CheckCircle,
          className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100",
          label: "Completed"
        };
      case "generating":
        return {
          icon: Loader2,
          className: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100",
          label: "Generating",
          animate: true
        };
      case "failed":
        return {
          icon: XCircle,
          className: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100",
          label: "Failed"
        };
      case "pending":
        return {
          icon: Clock,
          className: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100",
          label: "Pending"
        };
      default:
        return {
          icon: Clock,
          className: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100",
          label: status
        };
    }
  };

  const statusConfig = getStatusConfig(project.status);
  const StatusIcon = statusConfig.icon;
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  };

  const techStackArray = Array.isArray(project.techStack) ? project.techStack : [];

  if (viewMode === "list") {
    return (
      <>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground truncate">
                    {project.name}
                  </h3>
                  <Badge className={statusConfig.className}>
                    <StatusIcon className={`h-3 w-3 mr-1 ${statusConfig.animate ? 'animate-spin' : ''}`} />
                    {statusConfig.label}
                  </Badge>
                </div>
                
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                  {project.description}
                </p>
                
                <div className="flex items-center space-x-6 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>{formatDate(project.createdAt!)}</span>
                  </div>
                  
                  {project.downloadCount > 0 && (
                    <div className="flex items-center space-x-1">
                      <Download className="h-3 w-3" />
                      <span>{project.downloadCount} downloads</span>
                    </div>
                  )}
                  
                  {techStackArray.length > 0 && (
                    <div className="flex items-center space-x-1">
                      <Code className="h-3 w-3" />
                      <span>{techStackArray.slice(0, 2).join(", ")}</span>
                      {techStackArray.length > 2 && <span>+{techStackArray.length - 2}</span>}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center space-x-2 ml-4">
                {project.status === "completed" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onDownload(project.id)}
                    disabled={isDownloading}
                    data-testid={`button-download-${project.id}`}
                  >
                    {isDownloading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Download className="h-4 w-4" />
                    )}
                  </Button>
                )}
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" data-testid={`button-menu-${project.id}`}>
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem data-testid={`button-view-${project.id}`}>
                      <Eye className="mr-2 h-4 w-4" />
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem disabled>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Project
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="text-destructive"
                      onClick={() => setShowDeleteDialog(true)}
                      data-testid={`button-delete-menu-${project.id}`}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete Project
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </CardContent>
        </Card>

        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Project</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{project.name}"? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  onDelete(project.id);
                  setShowDeleteDialog(false);
                }}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                disabled={isDeleting}
                data-testid={`button-confirm-delete-${project.id}`}
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  "Delete Project"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </>
    );
  }

  // Grid view
  return (
    <>
      <Card className="hover:shadow-lg transition-all group">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-3">
              <Code className="h-6 w-6 text-primary" />
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  data-testid={`button-menu-${project.id}`}
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem data-testid={`button-view-${project.id}`}>
                  <Eye className="mr-2 h-4 w-4" />
                  View Details
                </DropdownMenuItem>
                <DropdownMenuItem disabled>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Project
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="text-destructive"
                  onClick={() => setShowDeleteDialog(true)}
                  data-testid={`button-delete-menu-${project.id}`}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete Project
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <CardTitle className="text-lg leading-tight">{project.name}</CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground line-clamp-3">
            {project.description}
          </p>
          
          {/* Tech Stack */}
          {techStackArray.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {techStackArray.slice(0, 3).map((tech, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {tech}
                </Badge>
              ))}
              {techStackArray.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{techStackArray.length - 3}
                </Badge>
              )}
            </div>
          )}
          
          {/* Status and Stats */}
          <div className="flex items-center justify-between pt-2">
            <Badge className={statusConfig.className}>
              <StatusIcon className={`h-3 w-3 mr-1 ${statusConfig.animate ? 'animate-spin' : ''}`} />
              {statusConfig.label}
            </Badge>
            
            <div className="flex items-center text-xs text-muted-foreground space-x-3">
              {project.downloadCount > 0 && (
                <div className="flex items-center space-x-1">
                  <TrendingUp className="h-3 w-3" />
                  <span>{project.downloadCount}</span>
                </div>
              )}
              <span>{formatDate(project.createdAt!)}</span>
            </div>
          </div>
          
          {/* Action Button */}
          {project.status === "completed" && (
            <Button
              className="w-full"
              variant="outline"
              onClick={() => onDownload(project.id)}
              disabled={isDownloading}
              data-testid={`button-download-${project.id}`}
            >
              {isDownloading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Downloading...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Download Project
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Project</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{project.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                onDelete(project.id);
                setShowDeleteDialog(false);
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
              data-testid={`button-confirm-delete-${project.id}`}
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Project"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
