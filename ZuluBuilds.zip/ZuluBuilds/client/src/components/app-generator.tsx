import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertProjectSchema } from "@shared/schema";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, 
  Loader2, 
  Lightbulb,
  Code,
  Database,
  Smartphone,
  Globe,
  Shield
} from "lucide-react";

const generateSchema = insertProjectSchema.extend({
  idea: z.string().min(20, "Please provide a more detailed description (at least 20 characters)"),
});

type GenerateFormData = z.infer<typeof generateSchema>;

interface AppGeneratorProps {
  onSuccess?: () => void;
}

const techStackOptions = [
  { id: "react", label: "React", icon: Code },
  { id: "vue", label: "Vue.js", icon: Code },
  { id: "angular", label: "Angular", icon: Code },
  { id: "express", label: "Express.js", icon: Database },
  { id: "fastapi", label: "FastAPI", icon: Database },
  { id: "django", label: "Django", icon: Database },
  { id: "postgresql", label: "PostgreSQL", icon: Database },
  { id: "mongodb", label: "MongoDB", icon: Database },
  { id: "redis", label: "Redis", icon: Database },
];

const featureOptions = [
  { id: "auth", label: "User Authentication", icon: Shield },
  { id: "responsive", label: "Responsive Design", icon: Smartphone },
  { id: "api", label: "REST API", icon: Globe },
  { id: "realtime", label: "Real-time Updates", icon: Sparkles },
  { id: "payments", label: "Payment Integration", icon: Shield },
  { id: "analytics", label: "Analytics Dashboard", icon: Code },
];

export function AppGenerator({ onSuccess }: AppGeneratorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTechStack, setSelectedTechStack] = useState<string[]>([]);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);

  const form = useForm<GenerateFormData>({
    resolver: zodResolver(generateSchema),
    defaultValues: {
      name: "",
      description: "",
      idea: "",
      isPublic: false,
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: GenerateFormData) => {
      const response = await apiRequest("POST", "/api/projects/generate", {
        ...data,
        techStack: selectedTechStack,
        features: selectedFeatures,
      });
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/usage"] });
      
      toast({
        title: "🎉 Project Generation Started!",
        description: `${data.name} is being generated. You'll be notified when it's ready.`,
      });
      
      form.reset();
      setSelectedTechStack([]);
      setSelectedFeatures([]);
      onSuccess?.();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to start project generation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: GenerateFormData) => {
    if (selectedTechStack.length === 0) {
      toast({
        title: "Tech Stack Required",
        description: "Please select at least one technology for your project.",
        variant: "destructive",
      });
      return;
    }
    
    generateMutation.mutate(data);
  };

  const handleTechStackToggle = (techId: string) => {
    setSelectedTechStack(prev => 
      prev.includes(techId) 
        ? prev.filter(id => id !== techId)
        : [...prev, techId]
    );
  };

  const handleFeatureToggle = (featureId: string) => {
    setSelectedFeatures(prev => 
      prev.includes(featureId) 
        ? prev.filter(id => id !== featureId)
        : [...prev, featureId]
    );
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <span>AI App Generator</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Project Basic Info */}
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="My Awesome App" 
                        {...field} 
                        data-testid="input-project-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Short Description</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="A brief description of your project" 
                        {...field} 
                        data-testid="input-project-description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="idea"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center space-x-2">
                      <Lightbulb className="h-4 w-4 text-primary" />
                      <span>Describe Your App Idea</span>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Create a task management app with real-time collaboration, user authentication, project boards with drag-and-drop functionality, time tracking, team notifications, and comprehensive reporting dashboard. The app should support multiple projects, role-based permissions, and integrate with popular tools like Slack and Google Calendar."
                        className="min-h-[120px] resize-none"
                        {...field}
                        data-testid="textarea-project-idea"
                      />
                    </FormControl>
                    <FormDescription>
                      Be as detailed as possible. Include features, functionality, and any specific requirements.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Tech Stack Selection */}
            <div className="space-y-4">
              <div>
                <FormLabel className="text-base font-semibold">Tech Stack</FormLabel>
                <FormDescription>
                  Select the technologies you'd like to use for your project
                </FormDescription>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {techStackOptions.map((tech) => (
                  <div
                    key={tech.id}
                    onClick={() => handleTechStackToggle(tech.id)}
                    className={`
                      cursor-pointer p-3 rounded-lg border transition-all
                      ${selectedTechStack.includes(tech.id)
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:border-primary/50 hover:bg-muted/50"
                      }
                    `}
                    data-testid={`tech-${tech.id}`}
                  >
                    <div className="flex items-center space-x-2">
                      <tech.icon className="h-4 w-4" />
                      <span className="font-medium text-sm">{tech.label}</span>
                    </div>
                  </div>
                ))}
              </div>
              
              {selectedTechStack.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {selectedTechStack.map((techId) => {
                    const tech = techStackOptions.find(t => t.id === techId);
                    return tech ? (
                      <Badge key={techId} variant="secondary">
                        {tech.label}
                      </Badge>
                    ) : null;
                  })}
                </div>
              )}
            </div>

            {/* Features Selection */}
            <div className="space-y-4">
              <div>
                <FormLabel className="text-base font-semibold">Key Features</FormLabel>
                <FormDescription>
                  Select additional features to include in your application
                </FormDescription>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {featureOptions.map((feature) => (
                  <div
                    key={feature.id}
                    onClick={() => handleFeatureToggle(feature.id)}
                    className={`
                      cursor-pointer p-3 rounded-lg border transition-all
                      ${selectedFeatures.includes(feature.id)
                        ? "border-accent bg-accent/10 text-accent-foreground"
                        : "border-border hover:border-accent/50 hover:bg-muted/50"
                      }
                    `}
                    data-testid={`feature-${feature.id}`}
                  >
                    <div className="flex items-center space-x-2">
                      <feature.icon className="h-4 w-4" />
                      <span className="font-medium text-sm">{feature.label}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Settings */}
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="isPublic"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="checkbox-public-project"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Make this project public</FormLabel>
                      <FormDescription>
                        Public projects can be discovered and viewed by other users
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full"
              disabled={generateMutation.isPending}
              data-testid="button-generate-project"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating Your App...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generate Application
                </>
              )}
            </Button>

            {/* Generation Info */}
            <div className="bg-muted/50 rounded-lg p-4">
              <div className="text-sm text-muted-foreground space-y-2">
                <p className="flex items-center space-x-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  <span>AI-powered generation typically takes 2-5 minutes</span>
                </p>
                <p className="flex items-center space-x-2">
                  <Code className="h-4 w-4 text-secondary" />
                  <span>Complete project with frontend, backend, and deployment configs</span>
                </p>
                <p className="flex items-center space-x-2">
                  <Shield className="h-4 w-4 text-accent" />
                  <span>Production-ready code with authentication and security</span>
                </p>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
