# Zulu AI API

## Overview

Zulu AI API is a full-stack application that enables users to generate production-ready applications using AI. The platform allows users to input project ideas and automatically generates complete application code with proper file structures, configurations, and deployment-ready components. Built with a focus on African innovation, it combines modern web technologies with AI-powered code generation to democratize software development.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built with React 18+ using Vite as the build tool, providing fast development and optimized production builds. The UI leverages shadcn/ui components built on top of Radix UI primitives with Tailwind CSS for styling. The application uses wouter for client-side routing, which is lighter than React Router while maintaining similar functionality.

State management is handled through TanStack Query (React Query) for server state and caching, eliminating the need for additional state management libraries like Redux. The application supports both light and dark themes through a custom theme provider that persists user preferences.

The component architecture follows a clear separation of concerns:
- **UI Components**: Reusable components in `/components/ui/` built with Radix UI
- **Feature Components**: Business logic components like `AppGenerator` and `ProjectCard`
- **Pages**: Route-level components for different application views
- **Hooks**: Custom hooks for authentication, theme management, and data fetching

### Backend Architecture
The server uses Express.js with TypeScript in ESM format, providing a modern Node.js experience. The architecture follows a modular approach with clear separation between routes, services, and data access layers.

Authentication is handled through Replit's OpenID Connect (OIDC) system using Passport.js strategies, providing secure user management without custom auth implementation. Session management uses PostgreSQL-backed sessions with automatic cleanup.

The server implements a clean service layer pattern:
- **Routes**: HTTP endpoint definitions and request/response handling
- **Services**: Business logic including AI integration and code generation
- **Storage**: Database abstraction layer with a defined interface
- **Middleware**: Authentication, logging, and error handling

### Database Design
The application uses PostgreSQL with Drizzle ORM for type-safe database operations. The schema includes:
- **Users Table**: Stores user profile information from OIDC authentication
- **Projects Table**: Contains generated projects with metadata, file contents, and deployment information
- **Sessions Table**: Manages user sessions (required for Replit Auth)
- **API Usage Table**: Tracks user API consumption and billing
- **User Settings Table**: Stores user preferences and configuration

The database uses UUID primary keys for security and implements proper foreign key relationships with cascade deletion for data integrity.

### AI Integration
The system integrates with OpenAI's API using the latest GPT-5 model for code generation. The AI service provides:
- **Project Analysis**: Analyzes user ideas to determine tech stack and complexity
- **Code Generation**: Creates complete file structures with working code
- **Architecture Planning**: Suggests optimal project organization and patterns

The code generator service orchestrates multiple AI calls to build comprehensive applications, including frontend components, backend APIs, database schemas, and configuration files.

### File Generation and Management
Generated projects are stored as JSON structures in the database, containing:
- Complete file tree with content
- Package.json and dependency information
- Configuration files (Docker, environment, etc.)
- Documentation and README files

The system supports downloading projects as ZIP files and provides preview functionality for generated code.

## External Dependencies

### Core Framework Dependencies
- **Frontend**: React 18+ with Vite for modern development experience
- **Backend**: Express.js with TypeScript for type-safe server development
- **Database**: PostgreSQL with Neon serverless hosting for scalable data storage
- **ORM**: Drizzle ORM for type-safe database operations and migrations

### Authentication Services
- **Replit OIDC**: Integrated authentication system for seamless user management
- **Session Management**: PostgreSQL-backed sessions with connect-pg-simple

### AI and External APIs
- **OpenAI API**: GPT-5 integration for intelligent code generation
- **Anthropic SDK**: Alternative AI provider for enhanced capabilities

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **Radix UI**: Accessible component primitives for complex UI elements
- **shadcn/ui**: Pre-built component library with consistent design system
- **Lucide React**: Consistent icon library for UI elements

### Development and Build Tools
- **TypeScript**: Type safety across the entire application stack
- **ESBuild**: Fast bundling for production server builds
- **PostCSS**: CSS processing with Tailwind integration
- **Vite Plugins**: Development enhancement tools including error overlays

### Deployment and Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting with automatic scaling
- **Environment Configuration**: dotenv for secure environment variable management
- **WebSocket Support**: Real-time communication capabilities for enhanced UX